package lt.viko.eif.g.siaudvytyte;

public class Main {
    public static void main(String[] args){

    }
}